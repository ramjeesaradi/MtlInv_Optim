packages <- c("lpSolve"
              ,"reshape"
              ,"plyr"
              ,"data.table"
              ,"dummies")
sapply(packages,install.packages)