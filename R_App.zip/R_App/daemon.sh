#!/bin/bash
chmod +x /usr/rfolder/R_App/run.sh
daemon -r -U /usr/rfolder/R_App/run.sh