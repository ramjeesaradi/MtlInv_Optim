scrapGen <- function(sol,params){
  obj1 <- invUtil(sol,params)
  obj2 <- wastemin(sol,params)
}

invUtil <- function(sol,params){
  cost <- sol %*% t(prams$sfgstk)
  cost <- 1000(1-sum(cost^2))
  return(1-sum(cost^2))
  
}

wastemin <- function(sol,params){
  cost <- sol %*%  t(prams$sfgwst)
  return(sum(cost^2))
}

gsub(".*?_","","S1A89220D_2021364-98.5-1250")
